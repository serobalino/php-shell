<html>
<head>
<title>RVT</title>
<META HTTP-EQUIV="Refresh" CONTENT="1; URL=http://localhost/reporte/rvtinforme.php">
</head>
<body>
</body>
</html>

