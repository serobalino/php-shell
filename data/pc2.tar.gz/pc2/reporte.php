<META http-equiv="Content-Type" content="text/html; charset=utf-8">
  <TITLE>Reportes RVT radio</TITLE>
</HEAD>
<BODY bgcolor="#F6E39E" background="./images/rvtletras.png">
<CENTER>
    <FONT face="Luxi Sans" size="4">
    <a href='http://www.rvtradio.com' class='external','HEIGHT=420,WIDTH=420,TOP=100,LEFT=100')'><img src='./images/logo.gif'></a>
  </CENTER>

  <HR noshade>

<?php

if ($enable) {
$file=$anio.'-'.$mes.'-'.$dia.'.log';
shell_exec("echo Reporte del dia  '$file' > '$reporte'");
shell_exec("grep -i '$comercial' ./rpt/'$file'  > /var/www/reporte/'$reporte'");
echo $dia;
}
else
{
shell_exec("echo Reporte del Mes '$mes' > '$reporte'");
for ( $counter = $dia0; $counter <= $dia1; $counter += 1) {
if ($counter < 10) {
$counter='0'.$counter;
}
shell_exec("echo '' >> '$reporte'");
shell_exec("echo Fecha: '$anio' - '$mes' - '$counter' >> '$reporte'");
$file=$anio.'-'.$mes.'-'.$counter.'.log';
shell_exec("grep -i '$comercial' ./rpt/'$file' >> /var/www/reporte/'$reporte'");
}
}

echo "<h5>El reporte ha sido generado, para descargarlo haga click en el botón</h5>";


//system("grep -i '$comercial' /mnt/zara/Zararadio/reportes/'$file'  > /var/www/reporte/'$reporte'");

echo "<a href=./$reporte><center><img src='./images/descarga.png'></img></center></a>";
echo "<h2>RVT radio</h2><font size=1>";

//Imprimir Reporte
$handle = @fopen("reporte.txt", "r");
if ($handle) {
    while (!feof($handle)) {
        $buffer = fgets($handle, 4096);
        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" .$buffer."<br>";
    }
    fclose($handle);
}
echo "</font><br>";
?>
