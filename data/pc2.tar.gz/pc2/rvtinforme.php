<META http-equiv="Content-Type" content="text/html; charset=utf-8"> 
  <TITLE>Reportes RVT radio</TITLE>
</HEAD>
<BODY bgcolor="#F6E39E" background="./images/rvtletras.png">
<CENTER>
    <FONT face="Luxi Sans" size="4">
    <a href='./ayuda/ayudasplat.php' class='external','HEIGHT=420,WIDTH=420,TOP=100,LEFT=100')'><img src='./images/logo.gif'></a>    
  </CENTER>

  <HR noshade>

<FORM METHOD="post" ACTION="reporte.php">


Ingrese el nombre de la pauta para el reporte&nbsp;&nbsp;&nbsp;<input type="text" name="comercial" size="20" value="LISTA">
</br>
Ingrese el nombre para el archivo reporte&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="reporte" size="10" value="reporte.txt">
</br>
Ingrese el número de Mes (Dos dígitos, ej: 08)&nbsp;&nbsp;&nbsp;<input type="text" name="mes" size="1" value="08">
&nbsp;&nbsp;&nbsp;&nbsp
<br>Ingrese el rango de días para el reporte: Inicio&nbsp;&nbsp;<input type="text" name="dia0" size="1" value="1">Fin<input type="text" name="dia1" size="1" value="31">
</br>Ingrese el año<input type="text" name="anio" size="3" value="2012">
</br>
<center>
<input type="submit" value="Generar Reporte" name="calcrp"></br>
</center>
<?php
$repo="reportes";
?>
</form>
